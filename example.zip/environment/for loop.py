
 
 
string_name = "shweta"
 
# Iterate over index
for element in range(0, len(string_name)):
    print(string_name[element])


    
  