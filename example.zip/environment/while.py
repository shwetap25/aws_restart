n=input("Enter Number");
n=int(n)
i = 1
while (i <= n):
   print (i)
   i = i+ 1