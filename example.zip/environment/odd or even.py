x = int(input("Enter a Number:")) 
if x % 2 == 0: 
  print("Given number is Even") 
else: 
  print("Given number is Odd")