
x = 10
y = 50
 
# Swapping of two variables
# Using third variable

temp = x
x = y
y = temp
 
print("Value of x:", x)
print("Value of y:", y)