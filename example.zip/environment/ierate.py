
list = [1, 3, 5, 7, 9]
  
# Using for loop
for i in list:
    print(i)